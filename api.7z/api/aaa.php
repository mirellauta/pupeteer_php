<?php

require 'vendor/autoload.php';

use rajvantchahal\TableauAPI\TableauAPI;

$tableauAPI = new TableauAPI('URL', 'USERNAME', 'PASSWORD', 'SITENAME');

$login = $tableauAPI->signIn();

?>